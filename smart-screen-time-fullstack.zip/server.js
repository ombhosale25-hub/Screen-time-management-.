const express = require("express");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || (process.env.NODE_ENV === "production"
  ? null
  : "local-development-secret-change-before-deploying");
if (!JWT_SECRET) {
  console.error("Missing JWT_SECRET. Set a long random JWT_SECRET in your deployment secrets.");
  process.exit(1);
}

const dataDir = process.env.DATA_DIR || path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "screen-time.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS usage_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  app_name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Other',
  duration_minutes INTEGER NOT NULL CHECK(duration_minutes > 0 AND duration_minutes <= 1440),
  usage_date TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_usage_user_date ON usage_records(user_id, usage_date);
CREATE TABLE IF NOT EXISTS goals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  daily_limit_minutes INTEGER NOT NULL DEFAULT 240 CHECK(daily_limit_minutes BETWEEN 1 AND 1440),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

app.use(express.json({ limit: "100kb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}
function setAuthCookie(res, token) {
  res.cookie("sst_token", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/"
  });
}
function auth(req, res, next) {
  try {
    const token = req.cookies.sst_token;
    if (!token) return res.status(401).json({ error: "Please log in to continue." });
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Your session has expired. Please log in again." });
  }
}
function validDate(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value) &&
    !Number.isNaN(Date.parse(value + "T00:00:00Z"));
}
function userSafe(user) {
  return { id: user.id, name: user.name, email: user.email };
}
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function startOfWeek(dateStr) {
  const d = new Date(dateStr + "T12:00:00");
  const day = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - day);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

app.post("/api/auth/register", (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (name.length < 2 || name.length > 80) return res.status(400).json({ error: "Name must be 2–80 characters." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 190) return res.status(400).json({ error: "Enter a valid email address." });
  if (password.length < 8 || password.length > 128) return res.status(400).json({ error: "Password must be at least 8 characters." });
  try {
    const hash = bcrypt.hashSync(password, 12);
    const result = db.prepare("INSERT INTO users (name,email,password_hash) VALUES (?,?,?)").run(name, email, hash);
    const user = { id: Number(result.lastInsertRowid), name, email };
    db.prepare("INSERT INTO goals (user_id,daily_limit_minutes) VALUES (?,240)").run(user.id);
    setAuthCookie(res, signToken(user));
    res.status(201).json({ user: userSafe(user) });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "An account with this email already exists." });
    console.error(e);
    res.status(500).json({ error: "Could not create account." });
  }
});

app.post("/api/auth/login", (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: "Incorrect email or password." });
  setAuthCookie(res, signToken(user));
  res.json({ user: userSafe(user) });
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("sst_token", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/" });
  res.json({ ok: true });
});

app.get("/api/auth/me", auth, (req, res) => {
  const user = db.prepare("SELECT id,name,email FROM users WHERE id = ?").get(req.user.id);
  if (!user) return res.status(401).json({ error: "Account not found." });
  res.json({ user });
});

app.get("/api/dashboard", auth, (req, res) => {
  const day = validDate(req.query.date) ? req.query.date : today();
  const weekStart = startOfWeek(day);
  const weekEndDate = new Date(weekStart + "T12:00:00");
  weekEndDate.setDate(weekEndDate.getDate() + 6);
  const weekEnd = `${weekEndDate.getFullYear()}-${String(weekEndDate.getMonth()+1).padStart(2,"0")}-${String(weekEndDate.getDate()).padStart(2,"0")}`;
  const userId = req.user.id;
  const goal = db.prepare("SELECT daily_limit_minutes FROM goals WHERE user_id=?").get(userId) || { daily_limit_minutes: 240 };
  const todayTotal = db.prepare("SELECT COALESCE(SUM(duration_minutes),0) AS total FROM usage_records WHERE user_id=? AND usage_date=?").get(userId, day).total;
  const weekTotal = db.prepare("SELECT COALESCE(SUM(duration_minutes),0) AS total FROM usage_records WHERE user_id=? AND usage_date BETWEEN ? AND ?").get(userId, weekStart, weekEnd).total;
  const categoryRows = db.prepare("SELECT category, SUM(duration_minutes) AS minutes FROM usage_records WHERE user_id=? AND usage_date=? GROUP BY category ORDER BY minutes DESC").all(userId, day);
  const weekRows = db.prepare("SELECT usage_date, SUM(duration_minutes) AS minutes FROM usage_records WHERE user_id=? AND usage_date BETWEEN ? AND ? GROUP BY usage_date ORDER BY usage_date").all(userId, weekStart, weekEnd);
  const recent = db.prepare("SELECT id,app_name,category,duration_minutes,usage_date,notes FROM usage_records WHERE user_id=? ORDER BY usage_date DESC,id DESC LIMIT 8").all(userId);
  const byDate = new Map(weekRows.map(r => [r.usage_date, r.minutes]));
  const weekly = [];
  for (let i=0;i<7;i++) {
    const d = new Date(weekStart + "T12:00:00"); d.setDate(d.getDate()+i);
    const date = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
    weekly.push({ date, label: d.toLocaleDateString("en-US",{weekday:"short"}), minutes: byDate.get(date)||0 });
  }
  res.json({
    date: day, goal: goal.daily_limit_minutes, todayTotal, remaining: Math.max(0,goal.daily_limit_minutes-todayTotal),
    goalPercent: Math.min(100, Math.round(todayTotal/goal.daily_limit_minutes*100)),
    weekTotal, weekAverage: Math.round(weekTotal/7), categories: categoryRows, weekly, recent
  });
});

app.get("/api/usage", auth, (req, res) => {
  const from = validDate(req.query.from) ? req.query.from : "0001-01-01";
  const to = validDate(req.query.to) ? req.query.to : "9999-12-31";
  const rows = db.prepare("SELECT id,app_name,category,duration_minutes,usage_date,notes FROM usage_records WHERE user_id=? AND usage_date BETWEEN ? AND ? ORDER BY usage_date DESC,id DESC LIMIT 500").all(req.user.id, from, to);
  res.json({ records: rows });
});

app.post("/api/usage", auth, (req, res) => {
  const appName = String(req.body.app_name || "").trim();
  const category = String(req.body.category || "Other").trim();
  const duration = Number(req.body.duration_minutes);
  const date = req.body.usage_date || today();
  const notes = String(req.body.notes || "").trim().slice(0, 500);
  if (!appName || appName.length > 100) return res.status(400).json({ error: "Application name is required (maximum 100 characters)." });
  if (!category || category.length > 60) return res.status(400).json({ error: "Choose a valid category." });
  if (!Number.isInteger(duration) || duration < 1 || duration > 1440) return res.status(400).json({ error: "Duration must be between 1 and 1440 minutes." });
  if (!validDate(date)) return res.status(400).json({ error: "Enter a valid date." });
  const result = db.prepare("INSERT INTO usage_records (user_id,app_name,category,duration_minutes,usage_date,notes) VALUES (?,?,?,?,?,?)").run(req.user.id, appName, category, duration, date, notes);
  res.status(201).json({ record: db.prepare("SELECT id,app_name,category,duration_minutes,usage_date,notes FROM usage_records WHERE id=? AND user_id=?").get(result.lastInsertRowid, req.user.id) });
});

app.put("/api/usage/:id", auth, (req, res) => {
  const id = Number(req.params.id);
  const appName = String(req.body.app_name || "").trim();
  const category = String(req.body.category || "Other").trim();
  const duration = Number(req.body.duration_minutes);
  const date = req.body.usage_date;
  const notes = String(req.body.notes || "").trim().slice(0, 500);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid record." });
  if (!appName || appName.length > 100 || !category || category.length > 60) return res.status(400).json({ error: "Enter a valid app name and category." });
  if (!Number.isInteger(duration) || duration < 1 || duration > 1440) return res.status(400).json({ error: "Duration must be between 1 and 1440 minutes." });
  if (!validDate(date)) return res.status(400).json({ error: "Enter a valid date." });
  const result = db.prepare("UPDATE usage_records SET app_name=?,category=?,duration_minutes=?,usage_date=?,notes=? WHERE id=? AND user_id=?").run(appName,category,duration,date,notes,id,req.user.id);
  if (!result.changes) return res.status(404).json({ error: "Record not found." });
  res.json({ ok: true });
});

app.delete("/api/usage/:id", auth, (req, res) => {
  const result = db.prepare("DELETE FROM usage_records WHERE id=? AND user_id=?").run(Number(req.params.id), req.user.id);
  if (!result.changes) return res.status(404).json({ error: "Record not found." });
  res.json({ ok: true });
});

app.get("/api/goals", auth, (req, res) => {
  const goal = db.prepare("SELECT daily_limit_minutes FROM goals WHERE user_id=?").get(req.user.id);
  res.json({ daily_limit_minutes: goal ? goal.daily_limit_minutes : 240 });
});
app.put("/api/goals", auth, (req, res) => {
  const limit = Number(req.body.daily_limit_minutes);
  if (!Number.isInteger(limit) || limit < 1 || limit > 1440) return res.status(400).json({ error: "Daily limit must be between 1 and 1440 minutes." });
  db.prepare("INSERT INTO goals (user_id,daily_limit_minutes,updated_at) VALUES (?,?,datetime('now')) ON CONFLICT(user_id) DO UPDATE SET daily_limit_minutes=excluded.daily_limit_minutes,updated_at=datetime('now')").run(req.user.id, limit);
  res.json({ daily_limit_minutes: limit });
});

app.get("/api/reports/weekly.csv", auth, (req, res) => {
  const rows = db.prepare("SELECT usage_date,app_name,category,duration_minutes,notes FROM usage_records WHERE user_id=? ORDER BY usage_date DESC,id DESC").all(req.user.id);
  const escape = v => `"${String(v ?? "").replace(/"/g,'""')}"`;
  const csv = ["Date,Application,Category,Duration (minutes),Notes", ...rows.map(r => [r.usage_date,r.app_name,r.category,r.duration_minutes,r.notes].map(escape).join(","))].join("\r\n");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", 'attachment; filename="screen-time-records.csv"');
  res.send(csv);
});

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "smart-screen-time" }));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ error: "API endpoint not found." });
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => console.log(`Smart Screen Time running on port ${PORT}`));
