# FocusFlow — Smart Screen Time Management

A full-stack, mobile-friendly screen-time logging website with user accounts, a persistent SQLite database, goals, dashboard analytics, and CSV export.

## Features

- Account registration and login with bcrypt password hashing.
- JWT stored in an HTTP-only cookie.
- Private user-specific screen-time records.
- Create, edit, and delete usage entries.
- Daily screen-time limit and remaining-time calculation.
- Weekly chart, category breakdown, and reports.
- CSV export of a user's saved records.
- SQLite database persisted in `data/screen-time.sqlite`.
- Responsive layout for desktop and mobile.

## Run locally

Requires Node.js 18 or newer.

```bash
npm install
npm start
```

Open `http://localhost:3000`.

The app creates its SQLite database automatically. In local development, a default JWT secret is used for convenience. Before publishing, set a long, random `JWT_SECRET` using your hosting provider's secret manager and set `NODE_ENV=production`.

## Deploy on Replit

1. Create a new Node.js Repl or import these files into your existing Repl.
2. Ensure `package.json`, `server.js`, and the `public` folder are at the project root.
3. Install dependencies (`npm install`).
4. Add a secret named `JWT_SECRET` with a long random value.
5. Set the run command to `npm start`.
6. Run the app and test `/api/health`.
7. Publish/deploy the app.
8. Confirm the deployment provides persistent storage for the `data` directory. If it does not, set `DATA_DIR` to a persistent mounted directory or use a managed database before production use.

## API summary

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/dashboard`
- `GET /api/usage`
- `POST /api/usage`
- `PUT /api/usage/:id`
- `DELETE /api/usage/:id`
- `GET /api/goals`
- `PUT /api/goals`
- `GET /api/reports/weekly.csv`
- `GET /api/health`

All endpoints except registration, login, logout, and health require authentication.

## Important limitation

This website records screen time that the user enters manually. A browser cannot automatically inspect usage of other Android apps. Automatic Android app usage collection requires a separate Android app and user-granted usage-access permission.

## Before public production use

This is a functional college-project starter, not a security-audited commercial service. Add rate limiting, monitoring, automated backups, CSRF review, account deletion flow, and a managed persistent database if required for your deployment. Never commit real secrets.
