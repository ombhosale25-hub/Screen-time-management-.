const $ = (id) => document.getElementById(id);
let authMode = "login";
let currentUser = null;
let dashboardData = null;
let weekChart = null, categoryChart = null, reportChart = null;
const palette = ["#7357f6","#23a77a","#4691e5","#efa64a","#e56e8a","#39b6c7","#a2a8b8"];
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };
const fmt = (minutes) => { const m = Math.max(0, Number(minutes)||0); const h = Math.floor(m/60), r=m%60; return h ? `${h}h${r ? ` ${r}m` : ""}` : `${r}m`; };
const niceDate = (s) => new Date(s+"T12:00:00").toLocaleDateString(undefined,{month:"short",day:"numeric",year:"numeric"});
function toast(message, error=false){const el=$("toast");el.textContent=message;el.className="toast show"+(error?" error":"");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.className="toast",3200);}
async function api(url, options={}) {
  const opts={...options,headers:{...(options.body?{"Content-Type":"application/json"}:{}),...(options.headers||{})},credentials:"same-origin"};
  const res=await fetch(url,opts);
  const type=res.headers.get("content-type")||"";
  const data=type.includes("application/json")?await res.json():null;
  if(!res.ok) throw new Error(data?.error||`Request failed (${res.status})`);
  return data;
}
function showAuth(mode="login"){
  authMode=mode;$("authView").classList.remove("hidden");$("appView").classList.add("hidden");
  $("loginTab").classList.toggle("active",mode==="login");$("signupTab").classList.toggle("active",mode==="signup");
  $("nameWrap").classList.toggle("hidden",mode!=="signup");$("name").required=mode==="signup";
  $("authTitle").textContent=mode==="login"?"Make time for what matters.":"Start your mindful routine.";
  $("authSubtitle").textContent=mode==="login"?"Sign in to understand your screen habits and build healthier routines.":"Create an account to keep your screen-time records in one place.";
  $("authSubmit").innerHTML=mode==="login"?'Log in <span>→</span>':'Create account <span>→</span>';
  $("password").autocomplete=mode==="login"?"current-password":"new-password";
}
function showApp(){
  $("authView").classList.add("hidden");$("appView").classList.remove("hidden");
  $("sideName").textContent=currentUser.name;$("sideEmail").textContent=currentUser.email;$("avatar").textContent=(currentUser.name||"U").charAt(0).toUpperCase();
  $("welcomeText").textContent=`Welcome back, ${currentUser.name.split(" ")[0]} 👋`;
  $("todayLabel").textContent=new Date().toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric"});
  $("dateEyebrow").textContent=new Date().toLocaleDateString(undefined,{month:"long",year:"numeric"}).toUpperCase();
}
function goPage(page){
  const names={dashboard:"Overview",tracker:"Screen-time log",reports:"Reports",goals:"Daily goal"};
  Object.keys(names).forEach(p=>$(p+"Page").classList.toggle("hidden",p!==page));
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  $("pageTitle").textContent=names[page]||"Overview";
  if(page==="tracker") loadRecords(); if(page==="goals") loadGoal(); if(page==="reports") loadReports();
  if(page==="dashboard") loadDashboard();
}
function empty(message,title="Nothing here yet"){return `<div class="empty-state"><strong>${title}</strong>${message}</div>`;}
function safe(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function recordTable(records, recent=false){
  if(!records.length)return empty("Add a screen-time entry to see your activity.","No entries yet");
  return `<table class="data-table"><thead><tr><th>APPLICATION</th><th>CATEGORY</th><th>DURATION</th><th>DATE</th>${recent?"":"<th>ACTIONS</th>"}</tr></thead><tbody>${records.map(r=>`<tr><td><div class="app-cell"><span class="app-symbol">${safe((r.app_name||"?").charAt(0).toUpperCase())}</span><span>${safe(r.app_name)}</span></div></td><td><span class="category-chip">${safe(r.category)}</span></td><td><strong>${fmt(r.duration_minutes)}</strong></td><td>${niceDate(r.usage_date)}</td>${recent?"":`<td><div class="row-actions"><button data-edit="${r.id}">Edit</button><button class="delete" data-delete="${r.id}">Delete</button></div></td>`}</tr>`).join("")}</tbody></table>`;
}
async function loadDashboard(){
  try{
    const d=await api("/api/dashboard");dashboardData=d;
    $("todayTotal").textContent=fmt(d.todayTotal);$("remaining").textContent=fmt(d.remaining);$("weekAverage").textContent=fmt(d.weekAverage);$("goalValue").textContent=fmt(d.goal);
    $("goalNote").textContent=d.todayTotal>d.goal?"Daily goal exceeded":`${Math.max(0,d.goal-d.todayTotal)} minutes of your goal left`;
    $("goalProgress").style.width=d.goalPercent+"%";$("goalPercent").textContent=`${d.goalPercent}% of daily limit used`;
    $("recentList").innerHTML=recordTable(d.recent,true);
    renderWeekChart("weekChart",d.weekly,false);renderCategoryChart(d.categories);renderBreakdown(d.categories,"categoryLegend");
  }catch(e){toast(e.message,true);}
}
function renderWeekChart(id,weekly,large){
  const canvas=$(id);if(!canvas||!window.Chart)return;
  const existing=id==="weekChart"?weekChart:reportChart;if(existing)existing.destroy();
  const chart=new Chart(canvas,{type:"bar",data:{labels:weekly.map(x=>x.label),datasets:[{label:"Minutes",data:weekly.map(x=>x.minutes),backgroundColor:weekly.map((x,i)=>x.date===today()?"#7357f6":"#dcd6ff"),borderRadius:7,borderSkipped:false,maxBarThickness:large?50:34}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>` ${fmt(c.raw)}`}}},scales:{x:{grid:{display:false},border:{display:false},ticks:{color:"#9299aa",font:{size:10}}},y:{beginAtZero:true,grid:{color:"#f0f1f6"},border:{display:false},ticks:{color:"#a2a8b5",font:{size:9},callback:v=>v>=60?`${Math.floor(v/60)}h`:v}}}}});
  if(id==="weekChart")weekChart=chart;else reportChart=chart;
}
function renderCategoryChart(categories){
  const c=$("categoryChart");if(!c||!window.Chart)return;if(categoryChart)categoryChart.destroy();
  const labels=categories.map(x=>x.category),values=categories.map(x=>x.minutes);
  categoryChart=new Chart(c,{type:"doughnut",data:{labels:labels.length?labels:["No data"],datasets:[{data:values.length?values:[1],backgroundColor:values.length?palette.slice(0,values.length):["#eceef4"],borderWidth:0,hoverOffset:4}]},options:{responsive:true,maintainAspectRatio:false,cutout:"72%",plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>values.length?` ${c.label}: ${fmt(c.raw)}`:"No entries yet"}}}}});
}
function renderBreakdown(categories,id){
  const el=$(id);if(!categories.length){el.innerHTML=empty("No usage recorded for today.");return;}
  const max=Math.max(...categories.map(c=>c.minutes),1);
  if(id==="categoryLegend")el.innerHTML=categories.map((c,i)=>`<span><i class="legend-dot" style="background:${palette[i%palette.length]}"></i>${safe(c.category)} · ${fmt(c.minutes)}</span>`).join("");
  else el.innerHTML=categories.map((c,i)=>`<div class="breakdown-item"><span>${safe(c.category)}</span><div class="breakdown-track"><div class="breakdown-bar" style="width:${c.minutes/max*100}%;background:${palette[i%palette.length]}"></div></div><span class="breakdown-min">${fmt(c.minutes)}</span></div>`).join("");
}
async function loadRecords(){
  try{const d=await api("/api/usage");$("allRecords").innerHTML=recordTable(d.records);bindRecordActions(d.records);}
  catch(e){toast(e.message,true);}
}
function bindRecordActions(records){
  document.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",async()=>{
    if(!confirm("Delete this screen-time entry?"))return;
    try{await api(`/api/usage/${b.dataset.delete}`,{method:"DELETE"});toast("Entry deleted.");await loadRecords();await loadDashboard();}catch(e){toast(e.message,true);}
  }));
  document.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>{
    const r=records.find(x=>x.id===Number(b.dataset.edit));if(!r)return;
    $("recordId").value=r.id;$("appName").value=r.app_name;$("category").value=r.category;$("duration").value=r.duration_minutes;$("usageDate").value=r.usage_date;$("notes").value=r.notes||"";
    $("recordFormTitle").textContent="Edit usage entry";$("saveRecord").textContent="Update entry";$("cancelEdit").classList.remove("hidden");$("usageForm").scrollIntoView({behavior:"smooth",block:"center"});
  }));
}
function resetUsageForm(){$("usageForm").reset();$("recordId").value="";$("usageDate").value=today();$("recordFormTitle").textContent="Add a usage entry";$("saveRecord").textContent="Save entry";$("cancelEdit").classList.add("hidden");}
$("usageForm").addEventListener("submit",async e=>{
  e.preventDefault();const id=$("recordId").value;
  const body={app_name:$("appName").value.trim(),category:$("category").value,duration_minutes:Number($("duration").value),usage_date:$("usageDate").value,notes:$("notes").value.trim()};
  try{await api(id?`/api/usage/${id}`:"/api/usage",{method:id?"PUT":"POST",body:JSON.stringify(body)});toast(id?"Entry updated.":"Usage saved.");resetUsageForm();await loadRecords();await loadDashboard();}
  catch(err){toast(err.message,true);}
});
$("cancelEdit").addEventListener("click",resetUsageForm);
async function loadGoal(){
  try{const d=await api("/api/goals");$("dailyLimit").value=d.daily_limit_minutes;document.querySelectorAll(".preset").forEach(b=>b.classList.toggle("selected",Number(b.dataset.minutes)===d.daily_limit_minutes));}catch(e){toast(e.message,true);}
}
$("goalForm").addEventListener("submit",async e=>{
  e.preventDefault();try{const d=await api("/api/goals",{method:"PUT",body:JSON.stringify({daily_limit_minutes:Number($("dailyLimit").value)})});toast("Daily goal saved.");document.querySelectorAll(".preset").forEach(b=>b.classList.toggle("selected",Number(b.dataset.minutes)===d.daily_limit_minutes));await loadDashboard();}catch(e){toast(e.message,true);}
});
document.querySelectorAll(".preset").forEach(b=>b.addEventListener("click",()=>{$("dailyLimit").value=b.dataset.minutes;document.querySelectorAll(".preset").forEach(x=>x.classList.toggle("selected",x===b));}));
async function loadReports(){
  try{const d=await api("/api/dashboard");$("reportWeekTotal").textContent=fmt(d.weekTotal);$("reportWeekAverage").textContent=fmt(d.weekAverage);renderWeekChart("reportChart",d.weekly,true);renderBreakdown(d.categories,"reportCategories");}catch(e){toast(e.message,true);}
}
function exportCSV(){window.location.href="/api/reports/weekly.csv";}
$("exportBtn").addEventListener("click",exportCSV);$("reportExport").addEventListener("click",exportCSV);
function openModal(){$("modalBackdrop").classList.remove("hidden");$("quickDate").value=today();$("quickApp").focus();}
function closeModal(){$("modalBackdrop").classList.add("hidden");$("quickForm").reset();}
$("quickAdd").addEventListener("click",openModal);$("trackerAdd").addEventListener("click",()=>{goPage("tracker");$("appName").focus();});$("closeModal").addEventListener("click",closeModal);$("modalBackdrop").addEventListener("click",e=>{if(e.target===$("modalBackdrop"))closeModal();});
$("quickForm").addEventListener("submit",async e=>{
  e.preventDefault();try{await api("/api/usage",{method:"POST",body:JSON.stringify({app_name:$("quickApp").value.trim(),category:$("quickCategory").value,duration_minutes:Number($("quickDuration").value),usage_date:$("quickDate").value})});closeModal();toast("Usage saved.");await loadDashboard();if(!$("trackerPage").classList.contains("hidden"))loadRecords();}catch(e){toast(e.message,true);}
});
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>goPage(b.dataset.page)));
document.querySelectorAll("[data-goto]").forEach(b=>b.addEventListener("click",()=>goPage(b.dataset.goto)));
$("loginTab").addEventListener("click",()=>showAuth("login"));$("signupTab").addEventListener("click",()=>showAuth("signup"));
$("authForm").addEventListener("submit",async e=>{
  e.preventDefault();const button=$("authSubmit");button.disabled=true;
  try{
    const body=authMode==="login"?{email:$("email").value.trim(),password:$("password").value}:{name:$("name").value.trim(),email:$("email").value.trim(),password:$("password").value};
    const d=await api(`/api/auth/${authMode==="login"?"login":"register"}`,{method:"POST",body:JSON.stringify(body)});
    currentUser=d.user;showApp();goPage("dashboard");toast(authMode==="login"?"Welcome back!":"Your account is ready.");
  }catch(err){toast(err.message,true);}finally{button.disabled=false;}
});
$("logoutBtn").addEventListener("click",async()=>{try{await api("/api/auth/logout",{method:"POST"});}catch{}currentUser=null;showAuth("login");toast("You have logged out.");});
async function boot(){
  $("usageDate").value=today();$("quickDate").value=today();
  try{const d=await api("/api/auth/me");currentUser=d.user;showApp();goPage("dashboard");}
  catch{showAuth("login");}
}
boot();
